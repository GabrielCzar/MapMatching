CREATE FUNCTION postgis_scripts_build_date()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2017-11-30 17:56:54'::text AS version
$$;

