CREATE FUNCTION postgis_raster_scripts_installed()
  RETURNS text
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT '2.4.2'::text || ' r' || 16113::text AS version
$$;

