CREATE FUNCTION st_distance_sphere(geom1 geometry, geom2 geometry)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
COST 300
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Distance_Sphere', 'ST_DistanceSphere', '2.2.0');
    SELECT public.ST_DistanceSphere($1,$2);
$$;

