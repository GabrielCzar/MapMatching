CREATE FUNCTION st_polygon(geometry, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)

$$;

