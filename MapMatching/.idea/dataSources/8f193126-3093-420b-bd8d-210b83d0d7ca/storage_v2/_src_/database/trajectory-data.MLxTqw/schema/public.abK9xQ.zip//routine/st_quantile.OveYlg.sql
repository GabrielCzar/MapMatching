CREATE FUNCTION st_quantile(rast raster, nband integer, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  RETURNS SETOF record
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, $2, TRUE, 1, $3)
$$;

