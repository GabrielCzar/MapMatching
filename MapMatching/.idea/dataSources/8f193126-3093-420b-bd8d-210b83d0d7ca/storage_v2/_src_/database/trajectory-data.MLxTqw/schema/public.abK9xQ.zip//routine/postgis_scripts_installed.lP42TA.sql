CREATE FUNCTION postgis_scripts_installed()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.4.2'::text || ' r' || 16113::text AS version
$$;

