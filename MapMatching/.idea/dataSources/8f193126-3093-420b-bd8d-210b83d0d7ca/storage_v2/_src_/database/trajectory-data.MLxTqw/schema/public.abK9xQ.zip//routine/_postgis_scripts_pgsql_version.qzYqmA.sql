CREATE FUNCTION "_postgis_scripts_pgsql_version"()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '96'::text AS version
$$;

