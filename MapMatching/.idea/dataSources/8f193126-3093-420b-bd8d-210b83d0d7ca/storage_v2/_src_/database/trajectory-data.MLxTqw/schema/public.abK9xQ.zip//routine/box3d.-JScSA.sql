CREATE FUNCTION box3d(raster)
  RETURNS box3d
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select box3d( public.ST_convexhull($1))
$$;

