CREATE FUNCTION raster_overlap(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.&&) $2::geometry
$$;

