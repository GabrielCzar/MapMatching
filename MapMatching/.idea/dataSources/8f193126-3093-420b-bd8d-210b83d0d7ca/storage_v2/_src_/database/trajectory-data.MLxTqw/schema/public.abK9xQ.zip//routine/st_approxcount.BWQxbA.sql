CREATE FUNCTION st_approxcount(rastertable text, rastercolumn text, sample_percent double precision)
  RETURNS bigint
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, $2, 1, TRUE, $3)
$$;

