CREATE FUNCTION st_quantile(rastertable text, rastercolumn text, nband integer, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  RETURNS SETOF record
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, $2, $3, TRUE, 1, $4)
$$;

