CREATE FUNCTION st_mapalgebrafct(rast raster, onerastuserfunc regprocedure)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, NULL)
$$;

