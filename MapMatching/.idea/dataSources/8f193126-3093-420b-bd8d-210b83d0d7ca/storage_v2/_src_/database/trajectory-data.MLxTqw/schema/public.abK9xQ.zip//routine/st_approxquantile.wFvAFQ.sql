CREATE FUNCTION st_approxquantile(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, sample_percent double precision, quantile double precision)
  RETURNS double precision
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, $3, $4, $5, ARRAY[$6]::double precision[])).value
$$;

