CREATE FUNCTION st_longestline(geom1 geometry, geom2 geometry)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_LongestLine(public.ST_ConvexHull($1), public.ST_ConvexHull($2))
$$;

