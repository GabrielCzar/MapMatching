CREATE FUNCTION st_asgeojson(text)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_AsGeoJson(1, $1::public.geometry,15,0);
$$;

